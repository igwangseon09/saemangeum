import os, re, io, tempfile, requests, pandas as pd
from bs4 import BeautifulSoup

HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; data-fetcher/1.0)"}

# 사전정보공표 상세/목록 페이지 URL을 필요시 추가하세요.
CANDIDATE_PAGES = [
    # 예시: 특정 공표 글 상세. 최신 글이 바뀌면 목록 페이지를 긁어 최신 상세 글로 들어가는 로직을 추가할 수 있습니다.
    "https://www.saemangeum.go.kr/",
]

def find_attachment_links(html, base_url):
    soup = BeautifulSoup(html, "lxml")
    links = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        text = (a.get_text() or "").strip()
        # 파일 확장자 우선
        if any(href.lower().endswith(ext) for ext in (".pdf", ".xlsx", ".xls", ".hwp")):
            links.append(requests.compat.urljoin(base_url, href))
        # 일부 사이트는 다운로드 핸들러를 사용
        if "fileDown" in href or "download" in href.lower():
            links.append(requests.compat.urljoin(base_url, href))
    # 중복 제거
    dedup = []
    for u in links:
        if u not in dedup:
            dedup.append(u)
    return dedup

def fetch_candidate_attachments():
    urls = []
    for page in CANDIDATE_PAGES:
        try:
            r = requests.get(page, headers=HEADERS, timeout=20)
            r.raise_for_status()
        except Exception:
            continue
        urls += find_attachment_links(r.text, page)
    # 후보 중 pdf/xlsx/xls를 우선
    sorted_urls = sorted(urls, key=lambda u: (".pdf" not in u.lower(), ".xlsx" not in u.lower(), ".xls" not in u.lower()))
    return sorted_urls

def download_file(url, outdir):
    local = os.path.join(outdir, os.path.basename(url.split("?")[0]))
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.raise_for_status()
    with open(local, "wb") as f:
        f.write(r.content)
    return local

def run_fetch(outdir):
    os.makedirs(outdir, exist_ok=True)
    candidates = fetch_candidate_attachments()
    results = []
    for url in candidates[:5]:
        try:
            path = download_file(url, outdir)
            results.append(path)
        except Exception:
            continue
    return results

if __name__ == "__main__":
    out = run_fetch("downloads")
    print("downloaded:", out)
