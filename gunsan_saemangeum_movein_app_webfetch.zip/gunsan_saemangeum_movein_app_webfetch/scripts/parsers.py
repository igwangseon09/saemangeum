import os, re, pandas as pd

def parse_pdf_with_tabula(pdf_path):
    try:
        import tabula
    except Exception as e:
        raise RuntimeError("tabula-py 미설치") from e
    try:
        dfs = tabula.read_pdf(pdf_path, pages="all", lattice=True)
    except Exception as e:
        # Java 미설치 등
        raise RuntimeError("tabula-py 실행 실패(Java 필요)") from e
    if not dfs:
        return pd.DataFrame()
    df = max(dfs, key=lambda d: d.shape[0]*d.shape[1]).copy()
    df.columns = [str(c).strip() for c in df.columns]
    colmap = {"공구":"공구", "구역":"공구", "연도":"입주연도", "입주연도":"입주연도", "업체명":"업체명", "기업명":"업체명"}
    for src, dst in list(colmap.items()):
        if src in df.columns and dst not in df.columns:
            df = df.rename(columns={src: dst})
    keep = [c for c in ["공구","입주연도","업체명"] if c in df.columns]
    if not keep:
        return pd.DataFrame()
    return df[keep]

def parse_excel(path):
    try:
        xls = pd.read_excel(path)
        return xls
    except Exception:
        return pd.DataFrame()

def normalize(df):
    import numpy as np
    if df.empty: return df
    # 필수 컬럼 누락 시 스킵
    for c in ["공구","입주연도","업체명"]:
        if c not in df.columns:
            return pd.DataFrame()
    df = df.dropna(how="all").copy()
    # 공구 정규화: 숫자만 추출 → n공구
    df["공구"] = (df["공구"].astype(str)
                  .str.replace(r"[^0-9]", "", regex=True))
    df = df[df["공구"].str.len()>0].copy()
    df["공구"] = df["공구"].astype(int).astype(str) + "공구"
    df["입주연도"] = pd.to_numeric(df["입주연도"], errors="coerce").astype("Int64")
    df["업체명"] = df["업체명"].astype(str).str.strip()
    return df[["공구","입주연도","업체명"]]

def aggregate(df):
    if df.empty: return pd.DataFrame()
    g = (df.groupby(["공구","입주연도"])
           .size()
           .reset_index(name="입주기업수"))
    return g
