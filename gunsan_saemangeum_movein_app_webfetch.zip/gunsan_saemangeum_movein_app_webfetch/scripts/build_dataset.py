import os, glob, pandas as pd
from scripts.fetch_latest import run_fetch
from scripts.parsers import parse_pdf_with_tabula, parse_excel, normalize

OUT_DIR = "data"
DL_DIR = "downloads"

def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    os.makedirs(DL_DIR, exist_ok=True)

    downloaded = run_fetch(DL_DIR)
    frames = []
    for path in downloaded:
        low = path.lower()
        df = None
        if low.endswith(".pdf"):
            try:
                df = parse_pdf_with_tabula(path)
            except Exception as e:
                print("PDF 파싱 실패:", e)
                df = None
        elif low.endswith((".xlsx",".xls")):
            df = parse_excel(path)
        elif low.endswith(".hwp"):
            print("HWP 파일은 자동 파싱 불가. 변환 필요:", path)
            continue
        if df is not None and not df.empty:
            frames.append(df)

    if not frames:
        print("수집된 표가 없습니다. 종료.")
        return

    raw = pd.concat(frames, ignore_index=True)
    norm = normalize(raw)
    if norm.empty:
        print("정규화 후 데이터가 비었습니다.")
        return
    norm.to_csv(os.path.join(OUT_DIR, "movein_raw_normalized.csv"), index=False, encoding="utf-8-sig")

    pivot = (norm.groupby(["공구","입주연도"]).size()
             .reset_index(name="입주기업수"))
    pivot.to_csv(os.path.join(OUT_DIR, "movein_counts_by_gonggu_year.csv"), index=False, encoding="utf-8-sig")
    print("저장 완료:", os.listdir(OUT_DIR))

if __name__ == "__main__":
    main()
