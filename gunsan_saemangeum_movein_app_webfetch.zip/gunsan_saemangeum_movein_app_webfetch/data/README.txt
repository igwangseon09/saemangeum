자동 수집된 CSV가 이 폴더에 저장됩니다. (GitHub Actions가 생성)
