import io, os, pandas as pd, streamlit as st, altair as alt

st.set_page_config(page_title="군산 새만금단지 입주기업 분석(웹수집)", layout="wide")
st.title("군산 새만금단지 9개 공구별 · 연도별 입주기업 분석")
st.caption("CSV 업로드 • 샘플 데이터 • 웹에서 최신 자료 불러오기")

@st.cache_data
def load_sample():
    return pd.read_csv("sample_data.csv")

def validate_columns(df: pd.DataFrame):
    required = {"공구", "입주연도", "업체명"}
    missing = required - set(df.columns)
    if missing:
        st.error(f"다음 컬럼이 필요합니다: {', '.join(missing)}")
        return False
    try:
        df["입주연도"] = pd.to_numeric(df["입주연도"], errors="coerce").astype("Int64")
    except Exception:
        st.error("`입주연도`는 숫자여야 합니다.")
        return False
    df["공구"] = df["공구"].astype(str)
    df["업체명"] = df["업체명"].astype(str)
    return True

def normalize(df):
    import numpy as np
    if df.empty: return df
    # 공구 → 숫자만 추출 후 n공구
    df["공구"] = (df["공구"].astype(str).str.replace(r"[^0-9]", "", regex=True))
    df = df[df["공구"].str.len()>0].copy()
    df["공구"] = df["공구"].astype(int).astype(str) + "공구"
    df["입주연도"] = pd.to_numeric(df["입주연도"], errors="coerce").astype("Int64")
    df["업체명"] = df["업체명"].astype(str).str.strip()
    return df

def fetch_latest_from_web():
    st.info("공식 사이트에서 첨부파일을 탐색 후 PDF/엑셀 표를 추출합니다. (HWP는 변환 필요)")
    from scripts.fetch_latest import run_fetch
    from scripts.parsers import parse_pdf_with_tabula, parse_excel
    import tempfile

    tmpdir = tempfile.mkdtemp()
    paths = run_fetch(tmpdir)
    frames = []
    for p in paths:
        low = p.lower()
        if low.endswith(".pdf"):
            try:
                df = parse_pdf_with_tabula(p)
            except Exception as e:
                st.warning(f"PDF 파싱 실패: {os.path.basename(p)} ({e})")
                df = None
        elif low.endswith((".xlsx",".xls")):
            df = parse_excel(p)
        elif low.endswith(".hwp"):
            st.warning(f"HWP는 자동 파싱 불가: {os.path.basename(p)} — 변환 후 CSV/엑셀 업로드 필요")
            df = None
        else:
            df = None
        if df is not None and not df.empty:
            frames.append(df)
    if not frames:
        st.stop()
    raw = pd.concat(frames, ignore_index=True)
    return raw

with st.sidebar:
    st.header("데이터 입력")
    uploaded = st.file_uploader("CSV 업로드 (공구, 입주연도, 업체명)", type=["csv"])
    col1, col2 = st.columns(2)
    use_sample = col1.checkbox("샘플 데이터", value=not bool(uploaded))
    fetch_now = col2.button("🌐 웹에서 최신 자료 불러오기")

    df = None
    if fetch_now:
        try:
            df = fetch_latest_from_web()
            st.success("웹 자료 수집 완료")
        except Exception as e:
            st.error(f"웹 수집 실패: {e}")
            st.stop()
    elif uploaded is not None:
        df = pd.read_csv(uploaded)
    elif use_sample:
        df = load_sample()

    if df is None:
        st.info("CSV를 업로드하거나 샘플 데이터를 선택하거나, '웹에서 최신 자료 불러오기'를 눌러주세요.")
        st.stop()

    # 정규화 + 검증
    df = normalize(df)
    if not validate_columns(df):
        st.stop()
    st.success("데이터 준비 완료")

# 필터
with st.expander("🔍 필터", expanded=True):
    all_gonggu = sorted(df["공구"].dropna().unique().tolist())
    sel_gonggu = st.multiselect("공구 선택", options=all_gonggu, default=all_gonggu)
    min_year, max_year = int(df["입주연도"].min()), int(df["입주연도"].max())
    year_range = st.slider("연도 범위", min_value=min_year, max_value=max_year, value=(min_year, max_year), step=1)
    text_query = st.text_input("업체명 검색(포함 일치)", "")

mask = df["공구"].isin(sel_gonggu) & df["입주연도"].between(year_range[0], year_range[1])
if text_query.strip():
    mask = mask & df["업체명"].str.contains(text_query.strip(), case=False, na=False)

fdf = df[mask].copy()

# 집계
yearly = (
    fdf.groupby(["입주연도"])
    .agg(입주기업수=("업체명", "count"))
    .reset_index()
    .sort_values("입주연도")
)

left, right = st.columns([1.1,1])
with left:
    st.subheader("연도별 입주 기업 수")
    if not yearly.empty:
        chart = (
            alt.Chart(yearly)
            .mark_bar()
            .encode(
                x=alt.X("입주연도:O", title="연도", sort=None),
                y=alt.Y("입주기업수:Q", title="기업 수"),
                tooltip=["입주연도", "입주기업수"]
            )
            .properties(height=380)
        )
        st.altair_chart(chart, use_container_width=True)
    else:
        st.info("해당 조건에 맞는 데이터가 없습니다.")

with right:
    st.subheader("요약")
    st.metric("표시 중인 공구 수", len(sel_gonggu))
    st.metric("표시 중 연도 범위", f"{year_range[0]}–{year_range[1]}")
    st.metric("표시 중 총 기업 수", int(fdf.shape[0]))

st.divider()

st.subheader("피벗테이블 (공구 × 연도)")
pivot = pd.pivot_table(
    fdf,
    index="공구",
    columns="입주연도",
    values="업체명",
    aggfunc="count",
    fill_value=0,
).sort_index()
st.dataframe(pivot, use_container_width=True)

st.subheader("다운로드")
col1, col2 = st.columns(2)
with col1:
    st.download_button(
        "집계 결과(CSV) 다운로드 - 연도별 합계",
        data=yearly.to_csv(index=False).encode("utf-8-sig"),
        file_name="yearly_counts.csv",
        mime="text/csv",
    )
with col2:
    csv_bytes = pivot.reset_index().to_csv(index=False).encode("utf-8-sig")
    st.download_button(
        "피벗테이블(CSV) 다운로드 - 공구×연도",
        data=csv_bytes,
        file_name="pivot_counts.csv",
        mime="text/csv",
    )

st.caption("HWP만 제공될 경우 자동 파싱이 제한될 수 있습니다. 변환된 PDF/엑셀/CSV를 업로드하면 바로 분석할 수 있습니다.")
