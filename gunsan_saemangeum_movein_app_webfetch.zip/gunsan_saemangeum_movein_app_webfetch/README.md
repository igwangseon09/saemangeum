# 군산 새만금단지 입주기업 분석 앱 (웹수집 + 자동갱신)

**기능**
- 9개 공구별 · 연도별 입주기업 수 집계/시각화
- CSV 업로드 또는 샘플 데이터 사용
- **웹에서 최신 자료 불러오기** 버튼(사전정보공표 페이지의 첨부 PDF/HWP/엑셀 시도)
- GitHub Actions로 **주 1회 자동 크롤링 → dataset 업데이트**

## 데이터 컬럼 규격
- `공구` : 예) `1공구` ~ `9공구`
- `입주연도` : 숫자 연도 (예: 2018)
- `업체명` : 기업명

## 로컬 실행
```bash
pip install -r requirements.txt
# tabula 사용을 위해 Java(JRE) 설치 필요 (Ubuntu: sudo apt-get install -y default-jre)
streamlit run app.py
```

## 배포 (Streamlit Community Cloud)
1. 이 코드를 GitHub 저장소에 올립니다.
2. Streamlit Cloud에서 New app → repo/branch 선택 → `app.py` 지정 → Deploy

> **주의(HWP)**: 공개자료가 HWP만 제공될 수 있습니다. 앱과 Actions는 우선 PDF/엑셀을 자동 파싱하며, HWP만 있는 경우에는 "변환 필요" 안내 후 사용자가 변환 파일을 업로드하도록 유도합니다.

## 자동 갱신(GitHub Actions)
- `/.github/workflows/build.yml`가 매주 월요일 00:00(UTC)에 `scripts/build_dataset.py`를 실행해 `data/` 폴더의 CSV를 갱신하고 커밋합니다.
- Streamlit 앱은 저장소의 최신 CSV를 읽어 사용하도록 구성할 수 있습니다(간단히 raw URL을 읽거나, 앱과 같은 저장소에 두고 배포 시점의 최신 파일 사용).
